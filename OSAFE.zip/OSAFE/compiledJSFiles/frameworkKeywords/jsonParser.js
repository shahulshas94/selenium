"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var testData = require('../../testData/testData.json');
//var testCaseSettings = require('D:/Projects/OSAFE_2.0/testData/testData/testCaseSettings.json');
class JsonParser {
    get() {
        return testData;
    }
}
exports.JsonParser = JsonParser;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianNvblBhcnNlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL2ZyYW1ld29ya0tleXdvcmRzL2pzb25QYXJzZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFDQSxJQUFJLFFBQVEsR0FBRyxPQUFPLENBQUMsOENBQThDLENBQUMsQ0FBQztBQUN2RSxrR0FBa0c7QUFFbEcsTUFBYSxVQUFVO0lBQ25CLEdBQUc7UUFDQyxPQUFPLFFBQVEsQ0FBQztJQUNwQixDQUFDO0NBSUo7QUFQRCxnQ0FPQyJ9