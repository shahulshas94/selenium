"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
var fs = require('fs');
class ScreenshotUtils {
    getScreenshotAs(filename) {
        protractor_1.browser.takeScreenshot().then(function (png) {
            var stream = fs.createWriteStream(protractor_1.browser.params.testOutputFolderPath + 'screenshots/' + filename + '.png');
            stream.write(new Buffer(png, 'base64'));
            stream.end();
        });
    }
}
exports.ScreenshotUtils = ScreenshotUtils;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiU2NyZWVuc2hvdFV0aWxzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vZnJhbWV3b3JrS2V5d29yZHMvU2NyZWVuc2hvdFV0aWxzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsMkNBQWtEO0FBQ2xELElBQUksRUFBRSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUd2QixNQUFhLGVBQWU7SUFFeEIsZUFBZSxDQUFDLFFBQWdCO1FBQzVCLG9CQUFPLENBQUMsY0FBYyxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRztZQUN2QyxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUMsaUJBQWlCLENBQUMsb0JBQU8sQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEdBQUcsY0FBYyxHQUFHLFFBQVEsR0FBRyxNQUFNLENBQUMsQ0FBQztZQUM1RyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksTUFBTSxDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQ3hDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNqQixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7Q0FDSjtBQVRELDBDQVNDIn0=