"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const HomePage_1 = require("../pages/HomePage");
const adminPage_1 = require("../pages/adminPage");
const assignPage_1 = require("../pages/assignPage");
const ScreenshotUtils_1 = require("../frameworkKeywords/ScreenshotUtils");
const jsonParser_1 = require("../frameworkKeywords/jsonParser");
let screenshotUtils = new ScreenshotUtils_1.ScreenshotUtils();
let hsoHomePage = new HomePage_1.HSOHomePage;
let hsoAdminPage = new adminPage_1.HSOAdminPage;
let hsoAssignPage = new assignPage_1.HSOAssignPage;
let td = new jsonParser_1.JsonParser();
describe('Assign Task', function () {
    it('validate Logo title', function () {
        hsoHomePage.getTitleofHomePageAndValidate('OnBoard');
    });
    it('Clickon Tab', function () {
        hsoHomePage.clickOnTAB('Assign');
    });
    it('Click on Unfold task', function () {
        hsoAssignPage.clickOnUnfoldtask('Centrepointe:');
    });
    it('Click on services', function () {
        hsoAssignPage.clickOnExpand('Infant and Early Childhood Mental Health');
    });
    it('Click on standards', function () {
        hsoAssignPage.clickOnExpand('Emergency Department');
    });
    it('Click on Section', function () {
        hsoAssignPage.clickOnExpand('2. BUILDING A PREPARED AND COMPETENT TEAM');
    });
    it('Click on Clause', function () {
        hsoAssignPage.clickOnExpand('1. Team members are qualified and have relevant competencies.');
        screenshotUtils.getScreenshotAs('Expand_Clause');
    });
    // it('Click on Button', function () {
    //     hsoAssignPage.clickOnQuestionCheckBox('1. Team members are qualified and have relevant competencies.');
    //     screenshotUtils.getScreenshotAs('Click_Button');
    // });  
    it('Click on Questionnaire', function () {
        hsoAssignPage.clickOnQuestionCheckBox('1. Orientation to the unique work environment in the emergency department is provided to new team members.');
        screenshotUtils.getScreenshotAs('Click_orientation');
    });
    //button[@class='mat-raised-button mat-primary']//span[text()='Assign']
    it('Click on Assign', function () {
        hsoAssignPage.clickOnAssign();
        screenshotUtils.getScreenshotAs('AssignButton');
    });
    it('Filter field for Assign', function () {
        hsoAdminPage.setFilter('ALHUCK');
    });
    it('Filter CheckBox', function () {
        hsoAssignPage.clickOnFilterCheckBox();
        screenshotUtils.getScreenshotAs('FilterCheckbox');
    });
    it('Click on Assign after filter', function () {
        hsoAssignPage.clickOnAssignafterFilter();
        screenshotUtils.getScreenshotAs('Assign after filter');
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGMwMDNfQXNzaWduLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3BlY3MvdGMwMDNfQXNzaWduLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQ0EsZ0RBQStDO0FBQy9DLGtEQUFpRDtBQUNqRCxvREFBbUQ7QUFDbkQsMEVBQXNFO0FBQ3RFLGdFQUE2RDtBQUU3RCxJQUFJLGVBQWUsR0FBRyxJQUFJLGlDQUFlLEVBQUUsQ0FBQztBQUM1QyxJQUFJLFdBQVcsR0FBRyxJQUFJLHNCQUFXLENBQUM7QUFDbEMsSUFBSSxZQUFZLEdBQUcsSUFBSSx3QkFBWSxDQUFDO0FBQ3BDLElBQUksYUFBYSxHQUFHLElBQUksMEJBQWEsQ0FBQztBQUN0QyxJQUFJLEVBQUUsR0FBRyxJQUFJLHVCQUFVLEVBQUUsQ0FBQztBQUUxQixRQUFRLENBQUMsYUFBYSxFQUFFO0lBRWhCLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRTtRQUN0QixXQUFXLENBQUMsNkJBQTZCLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDekQsQ0FBQyxDQUFDLENBQUM7SUFFSCxFQUFFLENBQUMsYUFBYSxFQUFFO1FBQ2QsV0FBVyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDLENBQUMsQ0FBQztJQUVILEVBQUUsQ0FBQyxzQkFBc0IsRUFBRTtRQUN2QixhQUFhLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDckQsQ0FBQyxDQUFDLENBQUM7SUFDSCxFQUFFLENBQUMsbUJBQW1CLEVBQUU7UUFDcEIsYUFBYSxDQUFDLGFBQWEsQ0FBQywwQ0FBMEMsQ0FBQyxDQUFDO0lBQzVFLENBQUMsQ0FBQyxDQUFDO0lBQ0gsRUFBRSxDQUFDLG9CQUFvQixFQUFFO1FBQ3JCLGFBQWEsQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUMsQ0FBQztJQUN4RCxDQUFDLENBQUMsQ0FBQztJQUNILEVBQUUsQ0FBQyxrQkFBa0IsRUFBRTtRQUNuQixhQUFhLENBQUMsYUFBYSxDQUFDLDJDQUEyQyxDQUFDLENBQUM7SUFDN0UsQ0FBQyxDQUFDLENBQUM7SUFDSCxFQUFFLENBQUMsaUJBQWlCLEVBQUU7UUFDbEIsYUFBYSxDQUFDLGFBQWEsQ0FBQywrREFBK0QsQ0FBQyxDQUFDO1FBQzdGLGVBQWUsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDckQsQ0FBQyxDQUFDLENBQUM7SUFDSCxzQ0FBc0M7SUFDdEMsOEdBQThHO0lBQzlHLHVEQUF1RDtJQUN2RCxRQUFRO0lBQ1IsRUFBRSxDQUFDLHdCQUF3QixFQUFFO1FBQ3pCLGFBQWEsQ0FBQyx1QkFBdUIsQ0FBQyw0R0FBNEcsQ0FBQyxDQUFDO1FBQ3BKLGVBQWUsQ0FBQyxlQUFlLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUN6RCxDQUFDLENBQUMsQ0FBQztJQUNILHVFQUF1RTtJQUN2RSxFQUFFLENBQUMsaUJBQWlCLEVBQUU7UUFDbEIsYUFBYSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQzlCLGVBQWUsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDcEQsQ0FBQyxDQUFDLENBQUM7SUFDSCxFQUFFLENBQUMseUJBQXlCLEVBQUU7UUFDMUIsWUFBWSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDLENBQUMsQ0FBQztJQUNILEVBQUUsQ0FBQyxpQkFBaUIsRUFBRTtRQUNsQixhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUN0QyxlQUFlLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDdEQsQ0FBQyxDQUFDLENBQUM7SUFDSCxFQUFFLENBQUMsOEJBQThCLEVBQUU7UUFDL0IsYUFBYSxDQUFDLHdCQUF3QixFQUFFLENBQUM7UUFDekMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQzNELENBQUMsQ0FBQyxDQUFDO0FBRVAsQ0FBQyxDQUFDLENBQUMifQ==