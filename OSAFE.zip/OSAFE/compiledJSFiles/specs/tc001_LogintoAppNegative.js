"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const loginPage_1 = require("../pages/loginPage");
const jsonParser_1 = require("../frameworkKeywords/jsonParser");
let hsoLoginPage = new loginPage_1.HSOLoginPage();
let td = new jsonParser_1.JsonParser();
describe('Logging in to HSO Application', function () {
    it('Navigating to URL', function () {
        protractor_1.browser.get('http://hso-portal.cleancode.com/#/login');
        protractor_1.browser.getTitle().then(function (title) {
            console.log("The title is  : " + title);
            expect(title.trim()).toBe('[object Object]');
            protractor_1.browser.sleep(3000);
            protractor_1.browser.manage().window().maximize();
        });
    });
    it('Enter UserName', function () {
        //hsoLoginPage.setUserName('admin@localhost');
        hsoLoginPage.setUserName(td.get().author2.username);
    });
    it('Enter Password', function () {
        hsoLoginPage.setPassword(td.get().author.password);
    });
    it('Login button', function () {
        hsoLoginPage.clickOnSigninButton();
    });
    it('validate Error Message', function () {
        hsoLoginPage.validateErrorMsg('Please check your credentials and try again.');
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGMwMDFfTG9naW50b0FwcE5lZ2F0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3BlY3MvdGMwMDFfTG9naW50b0FwcE5lZ2F0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsMkNBQWlEO0FBQ2pELGtEQUFpRDtBQUNqRCxnRUFBNkQ7QUFFN0QsSUFBSSxZQUFZLEdBQUcsSUFBSSx3QkFBWSxFQUFFLENBQUE7QUFDckMsSUFBSSxFQUFFLEdBQUcsSUFBSSx1QkFBVSxFQUFFLENBQUM7QUFFdEIsUUFBUSxDQUFDLCtCQUErQixFQUFFO0lBQ3RDLEVBQUUsQ0FBQyxtQkFBbUIsRUFBRTtRQUVwQixvQkFBTyxDQUFDLEdBQUcsQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO1FBQ3ZELG9CQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsS0FBSztZQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQyxDQUFBO1lBQ3ZDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUM3QyxvQkFBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNwQixvQkFBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBRXpDLENBQUMsQ0FBQyxDQUFBO0lBQ04sQ0FBQyxDQUFDLENBQUM7SUFDSCxFQUFFLENBQUMsZ0JBQWdCLEVBQUU7UUFFakIsOENBQThDO1FBQzlDLFlBQVksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN4RCxDQUFDLENBQUMsQ0FBQztJQUNILEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRTtRQUNqQixZQUFZLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDdkQsQ0FBQyxDQUFDLENBQUM7SUFDSCxFQUFFLENBQUMsY0FBYyxFQUFFO1FBQ2YsWUFBWSxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDdkMsQ0FBQyxDQUFDLENBQUM7SUFFSCxFQUFFLENBQUMsd0JBQXdCLEVBQUU7UUFDekIsWUFBWSxDQUFDLGdCQUFnQixDQUFDLDhDQUE4QyxDQUFDLENBQUM7SUFDbEYsQ0FBQyxDQUFDLENBQUM7QUFFUCxDQUFDLENBQUMsQ0FBQyJ9