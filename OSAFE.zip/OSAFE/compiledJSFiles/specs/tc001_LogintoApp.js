"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const loginPage_1 = require("../pages/loginPage");
const jsonParser_1 = require("../frameworkKeywords/jsonParser");
const ScreenshotUtils_1 = require("../frameworkKeywords/ScreenshotUtils");
let hsoLoginPage = new loginPage_1.HSOLoginPage();
let td = new jsonParser_1.JsonParser();
let screenshotUtils = new ScreenshotUtils_1.ScreenshotUtils();
describe('Logging in to HSO Application', function () {
    it('Navigating to URL', function () {
        protractor_1.browser.get('http://hso-portal.cleancode.com/#/login');
        protractor_1.browser.getTitle().then(function (title) {
            console.log("The title is  : " + title);
            expect(title.trim()).toBe('[object Object]');
            protractor_1.browser.sleep(3000);
            protractor_1.browser.manage().window().maximize();
        });
    });
    it('Enter UserName', function () {
        //hsoLoginPage.setUserName('admin@localhost');
        hsoLoginPage.setUserName(td.get().author.username);
        screenshotUtils.getScreenshotAs('screenShot_Username');
    });
    it('Enter Password', function () {
        hsoLoginPage.setPassword(td.get().author.password);
        screenshotUtils.getScreenshotAs('password');
    });
    it('Login button', function () {
        hsoLoginPage.clickOnSigninButton();
        screenshotUtils.getScreenshotAs('login');
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGMwMDFfTG9naW50b0FwcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NwZWNzL3RjMDAxX0xvZ2ludG9BcHAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSwyQ0FBaUQ7QUFDakQsa0RBQWlEO0FBQ2pELGdFQUE2RDtBQUM3RCwwRUFBc0U7QUFFdEUsSUFBSSxZQUFZLEdBQUcsSUFBSSx3QkFBWSxFQUFFLENBQUE7QUFDckMsSUFBSSxFQUFFLEdBQUcsSUFBSSx1QkFBVSxFQUFFLENBQUM7QUFDMUIsSUFBSSxlQUFlLEdBQUcsSUFBSSxpQ0FBZSxFQUFFLENBQUM7QUFFeEMsUUFBUSxDQUFDLCtCQUErQixFQUFFO0lBQ3RDLEVBQUUsQ0FBQyxtQkFBbUIsRUFBRTtRQUNwQixvQkFBTyxDQUFDLEdBQUcsQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO1FBQ3ZELG9CQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsS0FBSztZQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQyxDQUFBO1lBQ3ZDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUM3QyxvQkFBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNwQixvQkFBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3pDLENBQUMsQ0FBQyxDQUFBO0lBQ04sQ0FBQyxDQUFDLENBQUM7SUFDSCxFQUFFLENBQUMsZ0JBQWdCLEVBQUU7UUFFakIsOENBQThDO1FBQzlDLFlBQVksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNuRCxlQUFlLENBQUMsZUFBZSxDQUFDLHFCQUFxQixDQUFDLENBQUM7SUFDM0QsQ0FBQyxDQUFDLENBQUM7SUFDSCxFQUFFLENBQUMsZ0JBQWdCLEVBQUU7UUFDakIsWUFBWSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ25ELGVBQWUsQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDaEQsQ0FBQyxDQUFDLENBQUM7SUFDSCxFQUFFLENBQUMsY0FBYyxFQUFFO1FBQ2YsWUFBWSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFDbkMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUM3QyxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUMsQ0FBQyxDQUFDIn0=