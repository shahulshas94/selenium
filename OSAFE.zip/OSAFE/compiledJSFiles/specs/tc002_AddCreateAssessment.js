"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const HomePage_1 = require("../pages/HomePage");
const adminPage_1 = require("../pages/adminPage");
const jsonParser_1 = require("../frameworkKeywords/jsonParser");
let td = new jsonParser_1.JsonParser();
let hsoHomePage = new HomePage_1.HSOHomePage;
let hsoAdminPage = new adminPage_1.HSOAdminPage;
describe('Creating Assessment', function () {
    it('validate Logo title', function () {
        hsoHomePage.getTitleofHomePageAndValidate('OnBoard');
    });
    it('Clickon Tab', function () {
        hsoHomePage.clickOnTAB('Admin');
    });
    it('Click on Create Assessment', function () {
        hsoAdminPage.clickOnCreateAssessment();
    });
    it('Adding Name', function () {
        hsoAdminPage.setName('East Sector ER');
    });
    it('Description', function () {
        hsoAdminPage.setDescription('DescriptionAdded');
    });
    it('Click on Save', function () {
        hsoAdminPage.clickOnSave();
    });
    it('Filter field', function () {
        hsoAdminPage.setFilter('East Sector ER');
    });
    it('Click on Edit Criteria', function () {
        hsoAdminPage.clickOnEditCriteria();
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGMwMDJfQWRkQ3JlYXRlQXNzZXNzbWVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NwZWNzL3RjMDAyX0FkZENyZWF0ZUFzc2Vzc21lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFDQSxnREFBK0M7QUFDL0Msa0RBQWlEO0FBQ2pELGdFQUE2RDtBQUU3RCxJQUFJLEVBQUUsR0FBRyxJQUFJLHVCQUFVLEVBQUUsQ0FBQztBQUMxQixJQUFJLFdBQVcsR0FBRyxJQUFJLHNCQUFXLENBQUM7QUFDbEMsSUFBSSxZQUFZLEdBQUcsSUFBSSx3QkFBWSxDQUFDO0FBRXBDLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRTtJQUU1QixFQUFFLENBQUMscUJBQXFCLEVBQUU7UUFDdEIsV0FBVyxDQUFDLDZCQUE2QixDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3pELENBQUMsQ0FBQyxDQUFDO0lBRUgsRUFBRSxDQUFDLGFBQWEsRUFBRTtRQUNkLFdBQVcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDcEMsQ0FBQyxDQUFDLENBQUM7SUFFSCxFQUFFLENBQUMsNEJBQTRCLEVBQUU7UUFDN0IsWUFBWSxDQUFDLHVCQUF1QixFQUFFLENBQUM7SUFDM0MsQ0FBQyxDQUFDLENBQUM7SUFDSCxFQUFFLENBQUMsYUFBYSxFQUFFO1FBQ2QsWUFBWSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzNDLENBQUMsQ0FBQyxDQUFDO0lBQ0gsRUFBRSxDQUFDLGFBQWEsRUFBRTtRQUNkLFlBQVksQ0FBQyxjQUFjLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUNwRCxDQUFDLENBQUMsQ0FBQztJQUNILEVBQUUsQ0FBQyxlQUFlLEVBQUU7UUFDaEIsWUFBWSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQy9CLENBQUMsQ0FBQyxDQUFDO0lBQ0gsRUFBRSxDQUFDLGNBQWMsRUFBRTtRQUNmLFlBQVksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDLENBQUMsQ0FBQztJQUNILEVBQUUsQ0FBQyx3QkFBd0IsRUFBRTtRQUN6QixZQUFZLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztJQUN2QyxDQUFDLENBQUMsQ0FBQztBQUdQLENBQUMsQ0FBQyxDQUFDIn0=