import { browser, element, by } from "protractor";
var testData = require('../../testData/testData.json');
//var testCaseSettings = require('D:/Projects/OSAFE_2.0/testData/testData/testCaseSettings.json');

export class JsonParser {
    get() {
        return testData;
    }
    // getCase() {
    //     return testCaseSettings;
    // }
}


