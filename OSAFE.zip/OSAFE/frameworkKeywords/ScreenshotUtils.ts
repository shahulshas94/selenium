import { browser, element, by } from "protractor";
var fs = require('fs');


export class ScreenshotUtils {

    getScreenshotAs(filename: string) {
        browser.takeScreenshot().then(function (png) {
            var stream = fs.createWriteStream(browser.params.testOutputFolderPath + 'screenshots/' + filename + '.png');
            stream.write(new Buffer(png, 'base64'));
            stream.end();
        });
    }
}