import { browser, element, By } from 'protractor'
import { HSOLoginPage } from '../pages/loginPage'
import { JsonParser } from '../frameworkKeywords/jsonParser';

let hsoLoginPage = new HSOLoginPage()
let td = new JsonParser();

    describe('Logging in to HSO Application', function () {
        it('Navigating to URL', function () {

            browser.get('http://hso-portal.cleancode.com/#/login');
            browser.getTitle().then(function (title) {
                console.log("The title is  : " + title)
                expect(title.trim()).toBe('[object Object]');
                browser.sleep(3000);
                browser.manage().window().maximize();

            })
        });
        it('Enter UserName', function () {

            //hsoLoginPage.setUserName('admin@localhost');
            hsoLoginPage.setUserName(td.get().author2.username);
        });
        it('Enter Password', function () {
            hsoLoginPage.setPassword(td.get().author.password);
        });
        it('Login button', function () {
            hsoLoginPage.clickOnSigninButton();
        });

        it('validate Error Message', function () {
            hsoLoginPage.validateErrorMsg('Please check your credentials and try again.');
        });

    });