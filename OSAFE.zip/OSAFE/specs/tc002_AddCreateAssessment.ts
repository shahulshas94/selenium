import { browser, element, By } from 'protractor'
import { HSOHomePage } from '../pages/HomePage'
import { HSOAdminPage } from '../pages/adminPage'
import { JsonParser } from '../frameworkKeywords/jsonParser';

let td = new JsonParser();
let hsoHomePage = new HSOHomePage;
let hsoAdminPage = new HSOAdminPage;

describe('Creating Assessment', function () {
    
    it('validate Logo title', function () {
        hsoHomePage.getTitleofHomePageAndValidate('OnBoard');
    });

    it('Clickon Tab', function () {
        hsoHomePage.clickOnTAB('Admin');
    });

    it('Click on Create Assessment', function () {
        hsoAdminPage.clickOnCreateAssessment();
    });
    it('Adding Name', function () {
        hsoAdminPage.setName('East Sector ER');
    });
    it('Description', function () {
        hsoAdminPage.setDescription('DescriptionAdded');
    });
    it('Click on Save', function () {
        hsoAdminPage.clickOnSave();
    }); 
    it('Filter field', function () {
        hsoAdminPage.setFilter('East Sector ER');
    });
    it('Click on Edit Criteria', function () {
        hsoAdminPage.clickOnEditCriteria();
    });

    
});


