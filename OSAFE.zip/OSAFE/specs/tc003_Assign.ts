import { browser, element, By } from 'protractor'
import { HSOHomePage } from '../pages/HomePage'
import { HSOAdminPage } from '../pages/adminPage'
import { HSOAssignPage } from '../pages/assignPage'
import { ScreenshotUtils } from '../frameworkKeywords/ScreenshotUtils'
import { JsonParser } from '../frameworkKeywords/jsonParser';

let screenshotUtils = new ScreenshotUtils();
let hsoHomePage = new HSOHomePage;
let hsoAdminPage = new HSOAdminPage;
let hsoAssignPage = new HSOAssignPage;
let td = new JsonParser();

describe('Assign Task', function () {
        
        it('validate Logo title', function () {
            hsoHomePage.getTitleofHomePageAndValidate('OnBoard');
        });

        it('Clickon Tab', function () {
            hsoHomePage.clickOnTAB('Assign');
        });

        it('Click on Unfold task', function () {
            hsoAssignPage.clickOnUnfoldtask('Centrepointe:');
        });
        it('Click on services', function () {
            hsoAssignPage.clickOnExpand('Infant and Early Childhood Mental Health');
        });
        it('Click on standards', function () {
            hsoAssignPage.clickOnExpand('Emergency Department');
        });
        it('Click on Section', function () {
            hsoAssignPage.clickOnExpand('2. BUILDING A PREPARED AND COMPETENT TEAM');
        });
        it('Click on Clause', function () {
            hsoAssignPage.clickOnExpand('1. Team members are qualified and have relevant competencies.');
            screenshotUtils.getScreenshotAs('Expand_Clause');
        });
        // it('Click on Button', function () {
        //     hsoAssignPage.clickOnQuestionCheckBox('1. Team members are qualified and have relevant competencies.');
        //     screenshotUtils.getScreenshotAs('Click_Button');
        // });  
        it('Click on Questionnaire', function () {
            hsoAssignPage.clickOnQuestionCheckBox('1. Orientation to the unique work environment in the emergency department is provided to new team members.');
            screenshotUtils.getScreenshotAs('Click_orientation');
        });
        //button[@class='mat-raised-button mat-primary']//span[text()='Assign']
        it('Click on Assign', function () {
            hsoAssignPage.clickOnAssign();
            screenshotUtils.getScreenshotAs('AssignButton');
        });
        it('Filter field for Assign', function () {
            hsoAdminPage.setFilter('ALHUCK');
        });
        it('Filter CheckBox', function () {
            hsoAssignPage.clickOnFilterCheckBox();
            screenshotUtils.getScreenshotAs('FilterCheckbox');
        });
        it('Click on Assign after filter', function () {
            hsoAssignPage.clickOnAssignafterFilter();
            screenshotUtils.getScreenshotAs('Assign after filter');
        });

    });
