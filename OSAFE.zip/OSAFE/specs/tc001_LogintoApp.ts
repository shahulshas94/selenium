import { browser, element, By } from 'protractor'
import { HSOLoginPage } from '../pages/loginPage'
import { JsonParser } from '../frameworkKeywords/jsonParser';
import { ScreenshotUtils } from '../frameworkKeywords/ScreenshotUtils'

let hsoLoginPage = new HSOLoginPage()
let td = new JsonParser();
let screenshotUtils = new ScreenshotUtils();

    describe('Logging in to HSO Application', function () {
        it('Navigating to URL', function () {
            browser.get('http://hso-portal.cleancode.com/#/login');
            browser.getTitle().then(function (title) {
                console.log("The title is  : " + title)
                expect(title.trim()).toBe('[object Object]');
                browser.sleep(3000);
                browser.manage().window().maximize();
            })
        });
        it('Enter UserName', function () {
            //hsoLoginPage.setUserName('admin@localhost');
            hsoLoginPage.setUserName(td.get().author.username);
            screenshotUtils.getScreenshotAs('screenShot_Username');
        });
        it('Enter Password', function () {
            hsoLoginPage.setPassword(td.get().author.password);
            screenshotUtils.getScreenshotAs('password');
        });
        it('Login button', function () {
            hsoLoginPage.clickOnSigninButton();
            screenshotUtils.getScreenshotAs('login');
        });
    });

