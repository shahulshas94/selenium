import { browser, element, by } from "protractor";
export class HSOLoginPage{
    // using variables
    public static userName_fld = element(by.id("username"))
    public static password_fld = element(by.id("password"))
    public static logIn_btn = element(by.css("button[type='submit']"))
    public static errorMsgTxt = element(by.css(".alert.alert-danger.ng-star-inserted"))

    // using method
    setUserName(userName :string){
        expect(HSOLoginPage.userName_fld.isDisplayed()).toBeTruthy();
        HSOLoginPage.userName_fld.sendKeys(userName);
    }
    setPassword(password :string){
        expect(HSOLoginPage.password_fld.isDisplayed()).toBeTruthy();
        HSOLoginPage.password_fld.sendKeys(password);
    }
    clickOnSigninButton(){
        expect(HSOLoginPage.logIn_btn.isDisplayed()).toBeTruthy();
        HSOLoginPage.logIn_btn.click();
    }

    validateErrorMsg(errorMsg: string){

        HSOLoginPage.errorMsgTxt.getText().then(function(titleFromHomePage){
            expect(titleFromHomePage.trim()).toContain(errorMsg.trim());
            console.log(titleFromHomePage);
        })
}
}
