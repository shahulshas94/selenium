import { browser, element, by } from "protractor";
export class HSOHomePage {
    // using variables
    public static myTabs = element.all(by.css(".mat-tab-link"))
    public static logoText = element(by.css(".logo+span"))

    // using method
    clickOnTAB(tabName: string) {
        HSOHomePage.myTabs.each(function (element) {
            element.getText().then(function (text) {
                if (text.trim() == tabName.trim()) {
                    expect(element.isDisplayed()).toBeTruthy();
                    element.click();
                }
            });
        });
        expect(element(by.xpath('//a[contains(text(),"' + tabName + '") and @aria-current="true"]')).isDisplayed()).toBeTruthy();
    }
    getTitleofHomePageAndValidate(title: string) {

        HSOHomePage.logoText.getText().then(function (titleFromHomePage) {
            expect(titleFromHomePage.trim()).toBe(title);
            console.log(titleFromHomePage);
        })


    }

}
