import { browser, element, by } from "protractor";
export class HSOAdminPage {
   
    // using variables
    public static createAssessment_Add = element(by.css("mat-icon[aria-label='Add']"))
    public static nameAdd_fld = element(by.css("input[name='name']"))
    public static description_fld = element(by.css("textarea[placeholder='Description']"))
    public static Save_but = element(by.xpath("//span[text()='Save']"))
    public static filter_fld = element(by.css("input[placeholder='Filter']"))    
    public static EditCriteria_Click = element(by.xpath("//span[text()='Edit Criteria']"))

    // using method
     // using method
     clickOnCreateAssessment(){
        expect(HSOAdminPage.createAssessment_Add.isDisplayed()).toBeTruthy();
        HSOAdminPage.createAssessment_Add.click();
    }
    setName(name :string){
        expect(HSOAdminPage.nameAdd_fld.isDisplayed()).toBeTruthy();
        HSOAdminPage.nameAdd_fld.sendKeys(name);
    }
    setDescription(description :string){
        expect(HSOAdminPage.description_fld.isDisplayed()).toBeTruthy();
        HSOAdminPage.description_fld.click();
        HSOAdminPage.description_fld.sendKeys(description);
    }
    clickOnSave(){
        expect(HSOAdminPage.Save_but.isDisplayed()).toBeTruthy();
        browser.sleep(3000);
        browser.manage().timeouts().implicitlyWait(5000);
        HSOAdminPage.Save_but.click();
    }
    setFilter(filter :string){
        expect(HSOAdminPage.filter_fld.isDisplayed()).toBeTruthy();
        browser.manage().timeouts().implicitlyWait(5000);
        HSOAdminPage.filter_fld.sendKeys(filter);
    }
    clickOnEditCriteria(){
        expect(HSOAdminPage.EditCriteria_Click.isDisplayed()).toBeTruthy();
        browser.sleep(3000);
        browser.manage().timeouts().implicitlyWait(5000);
        HSOAdminPage.EditCriteria_Click.click();
    }
}
