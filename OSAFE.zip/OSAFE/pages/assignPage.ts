import { browser, element, by } from "protractor";
export class HSOAssignPage {
    // using variables

    public static assign_btn = element(by.xpath("//button[@class='mat-raised-button mat-primary']//span[text()='Assign']"))
    public static filter_fld = element(by.css("input[placeholder='Filter']"))
    public static checkBox_filter = element(by.css(".cdk-overlay-pane div[class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']"))
    public static assignafterFilter_btn = element(by.xpath("//div[@class='cdk-overlay-pane']//span[contains(text(),'Assign')]"))

    // using method
    // using method

    clickOnUnfoldtask(centre: String) {
        var UnfoldTask_Click = element(by.xpath("//p[contains(text(),'" + centre + "')]//preceding-sibling::button"))
        expect(UnfoldTask_Click.isDisplayed()).toBeTruthy();
        browser.sleep(3000);
        browser.manage().timeouts().implicitlyWait(5000);


        UnfoldTask_Click.click();
        UnfoldTask_Click.click();
        UnfoldTask_Click.click();

    }
    clickOnExpand(serviceExpand: String) {
        var Service_Click = element(by.xpath("//span[text()=' " + serviceExpand + " ']/../..//preceding-sibling::button"))
        expect(Service_Click.isDisplayed()).toBeTruthy();
        browser.sleep(3000);
        browser.manage().timeouts().implicitlyWait(5000);
        Service_Click.click();

    }
    clickOnQuestionCheckBox(serviceSExpand: String) {
        var Service_Clickk = element(by.xpath("//span[text()=' " + serviceSExpand + " ']/.."))
        expect(Service_Clickk.isDisplayed()).toBeTruthy();
        browser.sleep(3000);
        browser.manage().timeouts().implicitlyWait(5000);
        Service_Clickk.click();
    }
    clickOnAssign() {
        expect(HSOAssignPage.assign_btn.isDisplayed()).toBeTruthy();
        HSOAssignPage.assign_btn.click();
    }
    setFilter(filter: string) {
        expect(HSOAssignPage.filter_fld.isDisplayed()).toBeTruthy();
        HSOAssignPage.filter_fld.sendKeys(filter);
    }
    clickOnFilterCheckBox() {
        expect(HSOAssignPage.checkBox_filter.isDisplayed()).toBeTruthy();
        browser.sleep(5000);
        browser.manage().timeouts().implicitlyWait(5000);
        HSOAssignPage.checkBox_filter.click();
    }
    clickOnAssignafterFilter() {
        expect(HSOAssignPage.assignafterFilter_btn.isDisplayed()).toBeTruthy();
        HSOAssignPage.assignafterFilter_btn.click();
    }
}
